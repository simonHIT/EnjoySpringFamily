# 沒想到你是这样的HashSet

## 1、一场讨论下的疑惑

大家在平常的业务中，应该都会遇到这样的问题。

假设现在有一个有效用户对象的列表和失效用户对象的列表，用户的唯一标识是用户名，当程序送过来一个用户对象时，想判断这个用户是失效的还是有效的，这时该怎么处理呢?

我：这不简单嘛，把失效用户列表和有效用户列表的分别以用户名为key，null为value存成HashMap，校验时看看contains一下就好了

深老师：你为啥不直接把用户名称存成HashSet呢？

我：额，对哦。（实际上没咋用过HashSet，所以根本没想到，菜的太安详了。。。）

深老师：你猜，转换后的HashMap和HashSet哪个占用内存大啊？

我：Map吧......

深老师：你确定？

## 2、一次打脸的验证

急急忙忙打开IDE，写了个测试程序。

```java
import org.apache.lucene.util.RamUsageEstimator;

import java.util.HashMap;
import java.util.HashSet;

public class Main {

    public static void testMapAndSetSize() {
        HashMap<String, Object> testMap = new HashMap<>();
        HashSet<String> testSet = new HashSet<>();
        //初始化Map和Set
        initSetAndMap(testMap, testSet);
        //见证奇迹的时刻
        System.out.println("HashMap size is " + RamUsageEstimator.sizeOf(testMap));
        System.out.println("HashSet size is " + RamUsageEstimator.sizeOf(testSet));
        System.out.println("HashMap size - HashSet size is " + (RamUsageEstimator.sizeOf(testMap) - RamUsageEstimator.sizeOf(testSet)));
        System.out.println("Object size is " + RamUsageEstimator.sizeOf(temp));
    }


    private static void initSetAndMap(HashMap<String, Object> testMap, HashSet<String> testSet) {
        for (int i = 0; i < 1000; i++) {
            testMap.put("key" + i, null);
            testSet.add("key" + i);
        }
    }

    public static void main(String[] args) {
        testMapAndSetSize();
    }

}
```

没想到奇迹不仅没出现，脸却打得啪啪响！

```shell
MapAndSet.Main
Connected to the target VM, address: '127.0.0.1:51612', transport: 'socket'
HashMap size is 96176
HashSet size is 96208
HashMap size - HashSet size is -32
Disconnected from the target VM, address: '127.0.0.1:51612', transport: 'socket'
```

从运行结果来看，Map的内存占用竟然比Set的内存占用小，相差32字节！！！！

## 3、还是得好好的看看源码

打开HashSet的源码，一行一行的翻找，这怎么就比Map还大了呢！突然一个熟悉的字眼映入眼帘。

```java
public class HashSet<E>
    extends AbstractSet<E>
    implements Set<E>, Cloneable, java.io.Serializable
{
    static final long serialVersionUID = -5024744406713321676L;

    private transient HashMap<E,Object> map;

    // Dummy value to associate with an Object in the backing Map
    private static final Object PRESENT = new Object();

    /**
     * Constructs a new, empty set; the backing <tt>HashMap</tt> instance has
     * default initial capacity (16) and load factor (0.75).
     */
    public HashSet() {
        map = new HashMap<>();
    }
    ......
}
```

原来HashSet的底层通过HashMap实现的。

HashSet中不允许有重复元素，正是因为HashSet是基于HashMap实现的，HashSet中的元素都存放在HashMap的key上面，而value中的值都是统一的一个

```java
private static final Object PRESENT = new Object();
```

HashSet中add方法调用的是底层HashMap中的put()方法，而如果是在HashMap中调用put，首先会判断key是否存在，如果key存在则修改value值，如果key不存在这插入这个key-value。而在set中，因为value值没有用，也就不存在修改value值的说法，因此往HashSet中添加元素，首先判断元素（也就是key）是否存在，如果不存在则插入，如果存在则不插入，这样HashSet中就不存在重复值

```java
/**
     * Adds the specified element to this set if it is not already present.
     * More formally, adds the specified element <tt>e</tt> to this set if
     * this set contains no element <tt>e2</tt> such that
     * <tt>(e==null&nbsp;?&nbsp;e2==null&nbsp;:&nbsp;e.equals(e2))</tt>.
     * If this set already contains the element, the call leaves the set
     * unchanged and returns <tt>false</tt>.
     *
     * @param e element to be added to this set
     * @return <tt>true</tt> if this set did not already contain the specified
     * element
     */
    public boolean add(E e) {
        return map.put(e, PRESENT)==null;
    }

    /**
     * Removes the specified element from this set if it is present.
     * More formally, removes an element <tt>e</tt> such that
     * <tt>(o==null&nbsp;?&nbsp;e==null&nbsp;:&nbsp;o.equals(e))</tt>,
     * if this set contains such an element.  Returns <tt>true</tt> if
     * this set contained the element (or equivalently, if this set
     * changed as a result of the call).  (This set will not contain the
     * element once the call returns.)
     *
     * @param o object to be removed from this set, if present
     * @return <tt>true</tt> if the set contained the specified element
     */
    public boolean remove(Object o) {
        return map.remove(o)==PRESENT;
    }
```

同样的，相关HashSet的操作，基本上都是直接调用底层HashMap的相关方法来完成。

## 4、更深的疑惑

从源码我们看到HashSet是基于HashMap实现的，所以包含相同数量的同类型元素的Set相对较大，但是为什么是32个字节呢？

众所周知，类的方法并不会占用实例的内存空间，所以我们只需要找一下HashSet中相对HashMap多了哪些私有的成员变量。通过回顾代码，我们发现HashSet在HashMap的基础上多了一个静态的对象常量，没错，就是它

```java
private static final Object PRESENT = new Object();
```

难道这个空对象就占用了32个字节吗？那就让我们来验证一把，修改上面的测试程序，打印一下Object类实例的内存占用大小。

```java
public static void testMapAndSetSize() {
        HashMap<String, Object> testMap = new HashMap<>();
        HashSet<String> testSet = new HashSet<>();
        Object temp = new Object();
        //初始化Map和Set
        initSetAndMap(testMap, testSet);
        //每次打脸的时刻都值得铭记
        System.out.println("HashMap size is " + RamUsageEstimator.sizeOf(testMap));
        System.out.println("HashSet size is " + RamUsageEstimator.sizeOf(testSet));
        System.out.println("HashMap size - HashSet size is " + (RamUsageEstimator.sizeOf(testMap) - RamUsageEstimator.sizeOf(testSet)));
        System.out.println("Object size is " + RamUsageEstimator.sizeOf(temp));
    }
```

通过运行程序，一个Object类实例的大小进入视野。

```sh
Connected to the target VM, address: '127.0.0.1:51612', transport: 'socket'
HashMap size is 96176
HashSet size is 96208
HashMap size - HashSet size is -32
Object size is 16
Disconnected from the target VM, address: '127.0.0.1:51612', transport: 'socket'
```

啥！啥！啥！

一个Object类实例的大小是16字节，这个咋有些似曾相识呢！

## 5、抛砖引玉之java对象的内存结构

Java对象的内存结构包括：

- 对象头

- 实例数据

- 对齐填充


普通对象和数组对象，在内存结构上有一些不同，主要体现在对象头中。

普通对象的对象头由Mark Word和Klass Pointer组成，而数组对象，对象头还包括一个数组长度。

具体结构如下图：

![Java对象内存结构](image/Java对象内存结构.png)

### 5.1、对象头

普通对象：

- Mark Word:包含HashCode、分代年龄、锁标志等。

- Klass Pointer:指向当前对象的Class对象的内存地址。


数组对象：

- Mark Word:包含HashCode、分代年龄、锁标志等。

- Klass Pointer:指向当前对象的Class对象的内存地址。

- Length:数组长度


### 5.2、实例数据

存储对象的所有成员变量,static成员变量不包括在内。

### 5.3、对齐填充

Java对象的内存空间是8字节对齐的，因此总大小不是8的倍数时，会进行补齐。

### 5.4、各部分的内存占用大小

通过JOL的jar包，我们可以查看Object实例各部分的占用大小

64位JVM在默认配置下

![Java对象内存结构-对象头](image/Java对象内存结构-对象头.png)

可以看到，对象头中的Mark Word占8个字节，Klass Pointer占4个字节，然后补齐了4个字节，总大小为16个字节。

64位VM，关闭压缩配置下

![Java对象内存结构-对象头2](image/Java对象内存结构-对象头2.png)

和默认开启指针压缩不同的是，Klass Pointer占用8个字节，由于Mark Word+Klass Pointer=16,因此不需要再补齐。

## 6、冷静下来的思考

通过了解上面的知识，我们分析一下测试代码及HashMap、HashSet两兄弟的源码。

不难发现，因为HashSet中多了一个静态Object对象常量，而Object实例中并没有私有的数据成员，所以PRESENT的大小就是16字节。

那另外多出的16字节是哪里来的呢？

HashSet里也没有其他多余的私有数据成员了呀！哪里来的16字节？

深老师一语道破，你用面向对象的思想再审视下HashSet。

恍然大悟！HashSet与HashMap是关联关系，而HashSet的实例本身也是个Object实例。所以

```java
testSet  -  testMap = PRESENT + testSet的对象头 = PRESENT + object对象头 = object对象头 + object对象头 = 16 + 16 = 32
```

